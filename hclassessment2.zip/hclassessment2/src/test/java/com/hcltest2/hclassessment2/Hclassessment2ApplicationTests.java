package com.hcltest2.hclassessment2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Hclassessment2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
