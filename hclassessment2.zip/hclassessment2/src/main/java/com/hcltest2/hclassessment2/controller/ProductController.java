package com.hcltest2.hclassessment2.controller;


import com.hcltest2.hclassessment2.Service.ProductService;
import com.hcltest2.hclassessment2.enṭity.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/products")
public class ProductController {

    @Autowired
    private ProductService productService;

    @PostMapping
    public ResponseEntity<String> addProduct(@RequestBody Product product){
        String res=productService.AddPro(product);
        return ResponseEntity.ok(res);

    }
}
