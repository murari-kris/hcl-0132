package com.hcltest2.hclassessment2.Service;


import com.hcltest2.hclassessment2.enṭity.Customer;
import com.hcltest2.hclassessment2.repository.CustomerRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CustomerService {

    private CustomerRepository customerRepository;

    public CustomerService(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }

    public String registerCus(Customer customer) {

        Customer customer1=new Customer();

        customer1.setCustomername(customer.getCustomername());
        customer1.setCity(customer.getCity());
        customer1.setEmail(customer.getEmail());
        customer1.setMobile(customer.getMobile());
        customer1.setPassword(customer.getPassword());

        customerRepository.save(customer1);
        return
                "Registered Successfully";
    }

    public List<Customer> getAllCus() {

        List<Customer> customerList=customerRepository.findAll();
        return customerList;
    }

    public Customer getById(Long id) {

        Optional<Customer> chech=customerRepository.findById(id);

        if(!chech.isPresent()){
            return null;
        }

        Customer customer=chech.get();
   return  customer;


    }

    public String updateCust(Long id,Customer customer) {

        Optional<Customer> chech=customerRepository.findById(id);

        if(!chech.isPresent()){
            return null;
        }



        customer.setCustomername(customer.getCustomername());
        customer.setPassword(customer.getPassword());
        customer.setMobile(customer.getMobile());
        customer.setEmail(customer.getEmail());
        customer.setCity(customer.getCity());

        customerRepository.save(customer);

        return "Customer updated successfully";



    }

    public boolean DeleteCus(Long id) {

        Optional<Customer> chech=customerRepository.findById(id);

        if(!chech.isPresent()){
            return false;
        }

        customerRepository.deleteById(id);

        return true;

    }
}
