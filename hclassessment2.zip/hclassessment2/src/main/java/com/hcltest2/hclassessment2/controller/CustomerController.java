package com.hcltest2.hclassessment2.controller;


import com.hcltest2.hclassessment2.Service.CustomerService;
import com.hcltest2.hclassessment2.enṭity.Customer;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/customers")
public class CustomerController {

     private CustomerService customerService;

    public CustomerController(CustomerService customerService) {
        this.customerService = customerService;
    }

    @PostMapping("/register")
        public ResponseEntity<String> registerCustome(@RequestBody Customer customer){

                   String customer1=customerService.registerCus(customer);

                   return ResponseEntity.status(HttpStatus.CREATED).body(customer1);
        }


        @GetMapping
        public List<Customer> getAllCustomer(){
          List<Customer>  customerList=customerService.getAllCus();
          return customerList;

        }

        @GetMapping("/{id}")
    public ResponseEntity<Customer> getAllByid(@PathVariable Long id){

            Customer customerList=customerService.getById(id);

            return  ResponseEntity.ok(customerList);

        }



        @PutMapping("/{id}")
    public ResponseEntity<String> UpdateCustomer(@PathVariable Long id, @RequestBody Customer customer){
                    String mesg=customerService.updateCust(id,customer);
                    return ResponseEntity.ok(mesg);

        }


        @DeleteMapping("{id}")

    public ResponseEntity<Boolean> DeleteCustomer(@PathVariable Long id){

        boolean res=customerService.DeleteCus(id);

        return ResponseEntity.ok(res);
        }
}
