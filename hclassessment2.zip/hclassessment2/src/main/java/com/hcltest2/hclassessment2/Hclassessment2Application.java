package com.hcltest2.hclassessment2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Hclassessment2Application {

    public static void main(String[] args) {

        SpringApplication.run(Hclassessment2Application.class, args);

        System.out.println("demo application");
    }

}
