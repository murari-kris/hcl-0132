package com.hcltest2.hclassessment2.Service;


import com.hcltest2.hclassessment2.enṭity.Product;
import com.hcltest2.hclassessment2.repository.ProductRepo;
import org.springframework.beans.factory.annotation.Autowired;

public class ProductService {

    @Autowired
    private ProductRepo productRepo;
    public String AddPro(Product product) {

        Product product1=new Product();
        product1.setProductName(product.getProductName());
        product1.setCategory(product.getCategory());
       product1.setQuality(product.getQuality());
        product1.setPrice(product.getPrice());
        product1.setDesscription(product.getDesscription());

        productRepo.save(product1);
        return "Added Successfully";

    }
}
