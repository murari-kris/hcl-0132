package com.hcltest2.hclassessment2.repository;

import com.hcltest2.hclassessment2.enṭity.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CustomerRepository extends JpaRepository<Customer,Long> {
}
