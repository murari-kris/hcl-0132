package com.hcltest2.hclassessment2.repository;

import com.hcltest2.hclassessment2.enṭity.Product;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductRepo extends JpaRepository<Product,Long> {
}
